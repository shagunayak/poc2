package excel_io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import base_class.Person;

public class Excel_operation 
{

	
	
	String tcd_id,firstname,lastname,email,passowrd,exp_res,act_res,test_result;
	
	Person p;
	
   static ArrayList<Person> al=new ArrayList<Person>();
	
	
	public  ArrayList<Person> read_excel()
	{

		
		try {
			File f=new File("D:\\DATA_DRIVEN_POC\\Users_List.xlsx");
			FileInputStream fin=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fin);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
		    Iterator<Row> row=	sh.iterator();
		    Row firstrow =row.next();
		
	    	while(row.hasNext())
	     	{
			
	    		firstrow=row.next();
			
	    		tcd_id=(String)firstrow.getCell(0).getStringCellValue();
	    		
	    		firstname=(String)firstrow.getCell(1).getStringCellValue();
	    	
	    		lastname=(String)firstrow.getCell(2).getStringCellValue();
	    	
	    		email=(String)firstrow.getCell(3).getStringCellValue();
	    		
	    		passowrd=(String)firstrow.getCell(4).getStringCellValue();
	   
	  
	    		exp_res=(String)firstrow.getCell(12).getStringCellValue();
	    		
	    		p=new Person(tcd_id, firstname, lastname, email, passowrd,  exp_res);
	    		
	    		al.add(p);
		}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;


			
	}
	
	
	
	
	public void write_excel(int i,String act_res,String test_result) {
		
		
		try {
			File f=new File("D:\\DATA_DRIVEN_POC\\Users_List.xlsx");
			FileInputStream fin= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fin);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(i+1);
			
			XSSFCell cell=row.createCell(6);
			cell.setCellValue(act_res);
			XSSFCell cell1=row.createCell(7);
			cell1.setCellValue(test_result);
			 FileOutputStream fio=new FileOutputStream(f);
				
		     wb.write(fio);
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	

	
	
}






/*
 *public static void main(String args[]) {
		
		
		Excel_operation eo=new Excel_operation();
		eo.read_excel();
		
		
		
		
		for(Person p: al) {
			
			
			
			System.out.println("tcd_id="+p.getTcd_id());
			
		}
	}
	
 */





















/*Iterator<Cell> cell=firstrow.cellIterator();

while(cell.hasNext())
{
	Cell  value=cell.next();
	 value.
	
	//System.out.print(value.getCellType());
	if(value.getCellType() == 0) {
	
	}
	else {
		
	}
}
System.out.println();*/