package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base_class.Launch_browser;

public class Home_page {
	
	WebDriver dr;
	String home_title_exp_res="My Store",home_page_act_res,button_link_exp_res="Sign in",button_link_act_res;
	
	
        @FindBy(className="login")
        WebElement sign_in_link;

		public Home_page(WebDriver dr) {
			
			this.dr = dr;
			PageFactory.initElements(dr,this);
		}
        
        
		public String get_home_page_title() {
			
			return home_page_act_res=dr.getTitle();
		}
		
		
		public String get_sign_in_text()
		{
			return button_link_act_res=sign_in_link.getText();
		}
		
		public void get_login_page()
		{
			
			sign_in_link.click();
		}
        
        
	
}
