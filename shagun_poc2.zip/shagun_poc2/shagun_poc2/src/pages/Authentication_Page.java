package pages;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base_class.Person;
import excel_io.Excel_operation;

public class Authentication_Page {
	
	
	
	
	WebDriver dr;
	
	@FindBy(name="email")
	WebElement email;
	
	@FindBy(name="passwd")
    WebElement password;
	
	@FindBy(name="SubmitLogin")
	WebElement login_button;
	
	
    @FindBy(xpath="//li[contains(text(),'Invalid email address.')]")
    WebElement invalid;
    
    @FindBy(xpath="//li[contains(text(),'Authentication failed.')]")
    WebElement aut_prob;
	
    public Authentication_Page(WebDriver dr) {
		
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	 
	public String get_aut_page_title() {
		return dr.getTitle();
	}
	
	
public void set_email(String uname) {
		
		email.sendKeys(uname);
	}
	
	
	public void set_password(String pass) {
		password.sendKeys(pass);
	}
	
	public void click_sign() {
		login_button.click();
	}
	
	public void do_login(String uname,String pass,int i) {
		
		this.set_email(uname);
		this.set_password(pass);
		this.click_sign();
	}
	
	
	public boolean invalidDisplayed() {
		
		return invalid.isDisplayed();
	}
	
	
	public boolean autprobDisplayed() {
		return aut_prob.isDisplayed();
	}
	
	
}
