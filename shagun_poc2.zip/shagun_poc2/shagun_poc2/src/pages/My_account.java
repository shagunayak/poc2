package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class My_account {

	WebDriver dr;
	

	
	/*@FindBy(name="email")
	WebElement email;
	
	@FindBy(name="passwd")
    WebElement password;
	
	@FindBy(name="SubmitLogin")
	WebElement login_button;
	*/
	@FindBy(className="account")
	WebElement account_name;

	
	@FindBy(className="logout")
	WebElement sign_out;
	
	public My_account(WebDriver dr) {
		
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	
/*     public void set_email(String uname) {
		
		email.sendKeys(uname);
	}
	
	
	public void set_password(String pass) {
		password.sendKeys(pass);
	}
	
	public void click_sign() {
		login_button.click();
	}
	
	public void do_login(String uname,String pass,int i) {
		
		this.set_email(uname);
		this.set_password(pass);
		this.click_sign();
	}*/
	
	public String get_title() {
		return dr.getTitle();
		
	}
	public String get_user_name() {
		return account_name.getText();
	}
	
	public void  click_sign_out(){
		sign_out.click();
	}
	
	
	
}
