package base_class;

public class Person
{

	String tcd_id,firstname,lastname,email,passowrd,exp_res,act_res,test_result;


	public Person(String tcd_id, String firstname, String lastname, String email, String passowrd, String exp_res) {
		
		this.tcd_id = tcd_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.passowrd = passowrd;
		this.exp_res = exp_res;
		
	}



	public String getTcd_id() {
		return tcd_id;
	}



	public void setTcd_id(String tcd_id) {
		this.tcd_id = tcd_id;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassowrd() {
		return passowrd;
	}



	public void setPassowrd(String passowrd) {
		this.passowrd = passowrd;
	}



	public String getExp_res() {
		return exp_res;
	}



	public void setExp_res(String exp_res) {
		this.exp_res = exp_res;
	}



	public String getAct_res() {
		return act_res;
	}



	public void setAct_res(String act_res) {
		this.act_res = act_res;
	}



	public String getTest_result() {
		return test_result;
	}



	public void setTest_result(String test_result) {
		this.test_result = test_result;
	}

	
	
}
