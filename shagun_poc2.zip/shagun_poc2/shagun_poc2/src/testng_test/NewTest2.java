package testng_test;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base_class.Person;
import excel_io.Excel_operation;
import pages.Authentication_Page;
import pages.Home_page;
import pages.My_account;

public class NewTest2  extends NewTest1{
	
	
	@Test(priority=2,dataProvider="logintest")
	   public void my_acc(String exp_res) {
		  j=i+1;
		log.info("======================================================");
		   log.info("Test_Case_Id: TCD_ID"+j);
		
		  String uname=al.get(i).getEmail(),pass=al.get(i).getPassowrd();
		  log.info("Email: "+uname);
		  log.info("Password: "+pass);
		 
		 
		  ap.do_login(uname, pass, i);
		 log.info("login clicked");
		  
		 log.info("Expected result: "+ exp_result[i]);
		//  ma=new My_account(dr);
		  WebDriverWait wait = new WebDriverWait(dr,10);
		  wait.until(ExpectedConditions.elementToBeClickable(By.className("logout")));
		  
		 
		  String tit=ma.get_title();
		  log.info("MY  Account page_title "+tit);
		  Assert.assertEquals(tit, "My account - My Store");
		  String acc_name=ma.get_user_name();
		log.info("Actual_result:"+acc_name);
		String test;
		if(acc_name.compareTo(exp_result[i])==0)
			test="pass";
		else
			test="fail";
		  ma.click_sign_out();
		log.info("Test_result:"+test);
		log.info("=======================");
		  Assert.assertEquals(acc_name, exp_result[i]);
		  i++;
	 
	  }
	  
	  @DataProvider
	  public String[] logintest()
	  {  

	    return exp_result;
	    
	  }
	  
	

}
