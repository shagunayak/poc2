package testng_test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base_class.Launch_browser;
import base_class.Person;
import excel_io.Excel_operation;
import pages.Authentication_Page;
import pages.Home_page;
import pages.My_account;

public class NewTest1{
	
  static  Excel_operation eo=new Excel_operation();	
   static ArrayList<Person> al=new ArrayList<Person>();
    static Launch_browser lb=new Launch_browser();
	static WebDriver dr= lb.launch("http://automationpractice.com/index.php", "chrome");
	static Home_page hp =new Home_page(dr);
	static Authentication_Page ap=new Authentication_Page(dr);
	static My_account ma=new My_account(dr);
	 Logger log=Logger.getLogger("devpinoyLogger");
	//   //li[contains(text(),'Invalid email address.')]
	//   //li[contains(text(),'Authentication failed.')]
	
static	String [] exp_result;
	int i=0,j=0;
	 Excel_operation e;
	// ArrayList<Person> al;
	 
	 
	 
	 public String[] exp_result() {
			
			
			List<String>  list=new LinkedList<String>();
			
	          for(Person p: al) 
	          {
				list.add(p.getFirstname()+" "+p.getLastname());
			  }
	          
	          String[] arr = new String[list.size()]; 
	          for (int i =0; i < list.size(); i++) 
	              arr[i] = list.get(i);
			return arr;
			
		}
	
	 
	 @BeforeClass
	  public void beforeClass() 
	  {
		 log.info("All data initialization started");
		  al=eo.read_excel();
		  exp_result=exp_result();
		 log.info("All data loaded successfully");
	  }
	 

  
	@Test(priority=0)
      public void home() 
	 {
	  
//	  hp=new Home_page(dr);
		log.info("browser launched");
	  String page_title=hp.get_home_page_title();
	  log.info("Home Page Title: "+page_title);
	  Assert.assertEquals(page_title,"My Store");
	  String sign=hp.get_sign_in_text();
	  Assert.assertEquals(sign,"Sign in");
	  log.info("Sign text is present");
	  hp.get_login_page();
	  log.info("sign in clicked");
	  
      }
  
 @Test(priority=1)
  public void  aut_page() 
  {
	//  ap=new Authentication_Page(dr);
	  String page_title=ap.get_aut_page_title();
	 // System.out.println(page_title);
	  log.info("Login page Title: "+page_title);
   }
 
 @AfterClass
 public void afterclass()
 {  
	 dr.close();
	 log.info("browser closed");
 }
/*  @Test(priority=2,dataProvider="logintest")
   public void my_acc(String exp_res) {
	  
	  String uname=al.get(i).getEmail(),pass=al.get(i).getPassowrd();
	  System.out.println(uname);
	  ap.do_login(uname, pass, i);
	 
	  
	  
	  ma=new My_account(dr);
	  WebDriverWait wait = new WebDriverWait(dr,10);
	  wait.until(ExpectedConditions.elementToBeClickable(By.className("logout")));
	  
	 
	  
	  String acc_name=ma.get_user_name();
	  System.out.println(acc_name);
	  ma.click_sign_out();
	
	  Assert.assertEquals(acc_name, exp_result[i]);
	  i++;
  System.out.println(" done one");
  }
  
  @DataProvider
  public String[] logintest()
  {
	  
	  
	  exp_result=exp_result();

    return exp_result;
    
  }*/
  
}




















/*
 * @DataProvider
  public String[] logintest()
  {
	  exp_result=exp_result();
	  System.out.println(exp_result[0]);
    return exp_result;
    
  }*/
